import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.*;

public class Comms extends Thread {

    private Socket s;
    private ServerSocket ss;

    Comms(JFrame screen, int port, String IPAddress, boolean isServer) throws IOException {
        if (isServer) {
            // Szerver socket konstruálása
            ss = new ServerSocket(port);

            // Varakozo kepernyo
            JLabel waitMessage = new JLabel("Waiting for an other player to connect...");
            waitMessage.setForeground(Color.GRAY);
            waitMessage.setFont(new Font("Impact", Font.PLAIN, 40));
            waitMessage.setSize(800, 200);
            waitMessage.setLocation(120, 150);
            waitMessage.setVisible(true);
            screen.add(waitMessage);
            screen.revalidate();
            screen.repaint();

            // Kliens soket fogadására
            s = ss.accept();

            screen.getContentPane().remove(waitMessage);
            screen.revalidate();
            screen.repaint();

            System.out.println("Connection established");
        }else{
            // Kliens socket konstruálása
            s = new Socket(IPAddress, port);
        }
    }

    // ADATKÜLDÉS
    public synchronized void sendGridArray(Object[][] gridArray) throws IOException, ClassNotFoundException {

        // outputstream
        OutputStream outputStream = s.getOutputStream();

        // objektum kreálása
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

        // elküldi az adatot
        objectOutputStream.writeObject(gridArray);

        boolean ack = false;

        // vár a visszajelzésre, hogy megkapta
        //ObjectInputStream objectInputStream = null;
        while (!ack) {
            InputStream inputStream = s.getInputStream();
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            ack = (boolean) objectInputStream.readObject();
        }

        //objectInputStream.close();
        // bezárja a streamet
        //objectOutputStream.close();
    }

    public synchronized void sendShipArray(Ship[] shipArray) throws IOException, ClassNotFoundException {

        // outputstream
        OutputStream outputStream = s.getOutputStream();

        // objektum kreálása
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

        // elküldi az adatot
        objectOutputStream.writeObject(shipArray);

        boolean ack = false;

        // vár a visszajelzésre, hogy megkapta
        while(!ack) {
            InputStream inputStream = s.getInputStream();
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            ack = (boolean) objectInputStream.readObject();
        }
       // objectInputStream.close();

        // bezárja a streamet
       // objectOutputStream.close();
    }

    public synchronized void sendMyTurn(boolean myTurn) throws IOException, ClassNotFoundException {

        // outputstream
        OutputStream outputStream = s.getOutputStream();

        // objektum kreálása
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

        // elküldi az adatot
        objectOutputStream.writeObject(myTurn);

        boolean ack = false;

        // vár a visszajelzésre, hogy megkapta
        while(!ack) {
            InputStream inputStream = s.getInputStream();
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            ack = (boolean) objectInputStream.readObject();
        }
        // objectInputStream.close();

        // bezárja a streamet
        // objectOutputStream.close();
    }

    // ADATFOGADÁS
    public synchronized Object[][] recieveGridArray() throws IOException, ClassNotFoundException {

        // megynitása a streamnek
        InputStream inputStream = s.getInputStream();
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        // adat
        Object[][] gridArray = (Object[][]) objectInputStream.readObject();
        // lezárás
       // objectInputStream.close();

        // Acknowledge visszaküldése
        OutputStream outputStream = s.getOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

        boolean ack = true;
        objectOutputStream.writeObject(ack);
        //objectOutputStream.close();

        return gridArray;

    }

    public synchronized Ship[] recieveShipArray() throws IOException, ClassNotFoundException {

        // megynitása a streamnek
        InputStream inputStream = s.getInputStream();
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        // adat
        Ship[] shipArray = (Ship[]) objectInputStream.readObject();
        // lezárás
        //objectInputStream.close();

        // Acknowledge visszaküldése
        OutputStream outputStream = s.getOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

        boolean ack = true;
        objectOutputStream.writeObject(ack);
       // objectOutputStream.close();

        return shipArray;

    }

    public synchronized boolean recieveMyTurn() throws IOException, ClassNotFoundException {

        // megynitása a streamnek
        InputStream inputStream = s.getInputStream();
        ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        // adat
        boolean myTurn = (boolean) objectInputStream.readObject();
        // lezárás
        //objectInputStream.close();

        // Acknowledge visszaküldése
        OutputStream outputStream = s.getOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

        boolean ack = true;
        objectOutputStream.writeObject(ack);
        // objectOutputStream.close();

        return myTurn;

    }

}

