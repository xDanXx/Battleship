import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Grid extends JPanel implements MouseListener {
	private static final long serialVersionUID = 1L;
	private BufferedImage gridImage;
	private Object[][] gridArray;
	public static final int ZERO_X = 54; // X koordinátája a bal felső saroknak
	public static final int ZERO_Y = 56; // Y koordinátája a bal felső saroknak
	public static final int TILE_SIZE = 47; // A csempék méretei
	public static final int BORDER_SIZE = 5; // Az elválasztó vonalak vastagsága
	private volatile boolean isMyTurn;
	private boolean state;

	/*
	 * Konstruktor egy tömbbel meghívva, illetve elérési út (string)
	 */
	public Grid(Object[][] arr) {
		this(arr, "gridLabels.png");
	}

	/*
	 * Konstruktor egy tömbbel és elérési úttal (string)
	 */
	public Grid(Object[][] arr, String path) {
		gridArray = arr;
		isMyTurn = true;
		state = false;
		// A hátteret fehérre állítja, beállítja a méreteket
		setBackground(Color.white);
		setPreferredSize(new Dimension((ZERO_X+ arr.length + 1 + ((TILE_SIZE+BORDER_SIZE)*gridArray.length)),
				ZERO_Y+ arr.length + 1 + ((TILE_SIZE+BORDER_SIZE)*gridArray.length)));
		setSize(getPreferredSize());
		setLocation(0,0);

		try {
			gridImage = ImageIO.read(new File(path));
		} catch (IOException e) {
			System.out.println("Failed to load image");
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		// felrajzolja a gridet
		g2.drawImage(gridImage, 0, 0, this);

		// minden egyes négyzeten végighalad
		for (int i = 0; i < gridArray.length; i++) {
			for (int j = 0; j < gridArray[i].length; j++) {

				// megnézi, hogy van 1-es (azaz üres)  vagy még fel nem fedett mező (azaz 0)
				if (gridArray[i][j].equals((Object) 1) || ((gridArray[i][j]).getClass().getName().equals("ShipPart")
						&& !((ShipPart) gridArray[i][j]).isDestroy())) {
					// eltakarja a mezőt egy szürke dobozzal
					g2.setColor(Color.gray);
					g2.fillRect(ZERO_X + i + 1 + ((TILE_SIZE + BORDER_SIZE) * i), ZERO_Y + j + 1 + ((TILE_SIZE + BORDER_SIZE) * j),
							TILE_SIZE+(BORDER_SIZE/2)-1, TILE_SIZE+(BORDER_SIZE/2)-1);

				// Ha már van felfedett mező, ami találatot is kapott
				} else if ((gridArray[i][j]).getClass().getName().equals("ShipPart")) {
					// akkor kirajzolja az adott elemhez tartozó képet
					g2.drawImage(((ShipPart) gridArray[i][j]).getShipImage(),
							ZERO_X + i + ((TILE_SIZE + BORDER_SIZE) * i) + BORDER_SIZE/2,
							ZERO_Y + j + ((TILE_SIZE + BORDER_SIZE) * j) + BORDER_SIZE/2, this);
				}
			}
		}

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// Bal kattintás
		if (isMyTurn && e.getButton() == MouseEvent.BUTTON1) {

			// Az egér pozíciójából kiszámolja a kattintott grid mezőt (X koordináta)
			int value = e.getX();
			int counter1 = 0;
			while (ZERO_X + ((TILE_SIZE + BORDER_SIZE) * counter1) + BORDER_SIZE < value) {
				counter1++;
			}
			counter1--;

			// Az egér pozíciójából kiszámolja a kattintott grid mezőt (Y koordináta)
			int value2 = e.getY() - (TILE_SIZE / 2);
			int counter2 = 0;
			while (ZERO_Y + ((TILE_SIZE + BORDER_SIZE) * counter2) + BORDER_SIZE < value2) {
				counter2++;
			}
			counter2--;

			// Ha (counter1,counter2) a tömb pozíciója
			if (counter1 < gridArray.length && counter1 >= 0) {
				if (counter2 < gridArray[0].length && counter2 >= 0) {

					// Ha a tömb eleme nem egy hajó darab, hanem konstans 1
					// azaz a mezőn nincsen hajó
					if (gridArray[counter1][counter2].equals((Object) 1)) {
						// akkor 0-ba állítom, felfedezettnek tekintem
						gridArray[counter1][counter2] = 0;
						repaint();

						// vége a körnek
						isMyTurn = false;

						// Ha a tömb eleme egy hajó darab, ami még nincs meglőve
						// azaz a mezőn eltalát egy hajórészt
					} else if ((gridArray[counter1][counter2]).getClass().getName().equals("ShipPart")
							&& !((ShipPart) gridArray[counter1][counter2]).isDestroy()) {
						// akkor az a hajó találatot kapott
						((ShipPart) gridArray[counter1][counter2]).destroy();
						repaint();
						// vége a körnek
						isMyTurn = false;
					}
					state = false;
				}
			}
		}else if(!isMyTurn && e.getButton() == MouseEvent.BUTTON1){
			state = true;
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	/*
	 * visszaadja, hogy tart-e még a kör
	 */
	public boolean getIsMyTurn() {
		return isMyTurn;
	}

	/*
	 * átállítja, hogy tart-e még a kör
	 */
	public void setIsMyTurn(boolean t) {
		isMyTurn = t;
	}

	/*
	 * Visszaadja, a mezőket tartalmazó tömböt
	 *  -> 1: nincs hajó
	 *  -> egyébként shipPart
	 */
	public Object[][] getGridArray() {
		return gridArray;
	}

	/*
	 * átállítja a mezőket tartalmazó tömböt
	 */
	public void setGridArray(Object[][] arr) {
		gridArray = arr;
	}
	
	public boolean getState(){
		return state;
	}
	
	public void setState(boolean s){
		state = s;
	}

}
