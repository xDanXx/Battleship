import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class GridCreator extends JPanel {
	private static final long serialVersionUID = 1L;
	private BufferedImage gridImage = null;
	private Object[][] gridArray;
	private JPanel[] panelArray;
	private JButton finish;
	private JFrame screen;
	private Ship[] shipArray;
	private volatile boolean setupOver = false;
	public static final int ZERO_X = 54;
	public static final int ZERO_Y = 56;
	public static final int TILE_SIZE = 47;
	public static final int BORDER_SIZE = 5;
	public static boolean currentlyPlacingShip = false;
	private static int LARGEST_SHIP_SIZE = 5;
	private static int GRID_SIZE = 10;

	// ########## FÜGGVÉNYEK ##############

	// A "GameLogic"-ban meghívott konstruktor
	public GridCreator(Ship[] shipArray, JFrame app) {
		this(shipArray,"gridLabels.png", app);
	}

	// A tényleges konstruktor
	public GridCreator(Ship[] shipArray, String path, JFrame app) {

		setLayout(null);
		setBackground(Color.white);
		setLocation(0,0);
		screen = app;

		Object[][] grid = new Object[GRID_SIZE][GRID_SIZE];
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				grid[i][j] = 1;
			}
		}

		gridArray = grid;
		this.shipArray = shipArray;
		panelArray = new JPanel[shipArray.length];

		try {
			gridImage = ImageIO.read(new File(path));
		} catch (IOException e) {
			System.out.println("Failed to load image");
		}

	}

	/*
	 * Felépíti a Gridet
	 */
	public void initGrid() {
		
		// Ablak méreteinek beállítása
		int windowWidth = ZERO_X + ((TILE_SIZE + BORDER_SIZE) * gridArray.length) + (2 * BORDER_SIZE) + 50
				+ ((LARGEST_SHIP_SIZE + 1) * TILE_SIZE);
		int windowHeight = ZERO_Y + ((TILE_SIZE + BORDER_SIZE) * (gridArray.length + 1));
		if (windowHeight < 2 * TILE_SIZE + (shipArray.length * (TILE_SIZE + BORDER_SIZE + 2))) {
			windowHeight = 2 * TILE_SIZE + (shipArray.length * (TILE_SIZE + BORDER_SIZE + 2));
		}
		screen.setPreferredSize(new Dimension(windowWidth, windowHeight));
		screen.setMinimumSize(new Dimension(windowWidth, windowHeight));
		screen.pack();
		setSize(screen.getContentPane().getSize());

		// Label konsturálása a grid képpel, és ezt a képernyőre pakolja
		JLabel gridLabel = new JLabel(new ImageIcon(gridImage));
		gridLabel.setSize(ZERO_X + gridArray.length + 1 + ((TILE_SIZE + BORDER_SIZE) * gridArray.length),
				ZERO_Y + gridArray.length + 1 + ((TILE_SIZE + BORDER_SIZE) * (gridArray.length)));
		gridLabel.setLocation(0, 0);
		gridLabel.setHorizontalAlignment(SwingConstants.LEFT);
		gridLabel.setVerticalAlignment(SwingConstants.TOP);
		add(gridLabel);

		int buttonXPos = gridLabel.getWidth();


		// A hajók elhelyezést véglegesítő gomb: Finish
		finish = new JButton("Finish");
		finish.setBounds(buttonXPos, TILE_SIZE - 5, screen.getWidth() - buttonXPos, screen.getHeight());
		finish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setupOver = true;
			}
		});
		add(finish);
		// A gomb láthatósága
		finish.setVisible(false);

		// Minden hajót megvizsgál
		for (int j = 0; j < shipArray.length; j++) {
			final int shipNum = j;

			// Panel a hajónak
			JPanel panel = new JPanel();
			panel.setBackground(Color.WHITE);
			panel.setOpaque(false);
			panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
			panel.add(Box.createRigidArea(new Dimension(0, 0)));

			// Végighalad az egyes ship részeken
			for (int i = 0; i < shipArray[j].getShipParts().length; i++) {
				// Egyes label-höz hozzárendeli a képet
				ImageIcon icon = new ImageIcon(shipArray[j].getShipParts()[i].getShipImage());
				JLabel label = new JLabel(icon);
				panel.add(label);
				panel.add(Box.createRigidArea(new Dimension(BORDER_SIZE + 2, 0)));

			}
			panel.setLocation(ZERO_X + ((TILE_SIZE + BORDER_SIZE) * gridArray.length) + (2 * BORDER_SIZE) + 50,
					TILE_SIZE + BORDER_SIZE + 2 + (j * (TILE_SIZE + BORDER_SIZE + 2)));
			panel.setSize(shipArray[j].getShipParts().length * (TILE_SIZE + BORDER_SIZE), TILE_SIZE);
			shipArray[shipNum].setStartingPosition(panel.getLocation());
			add(panel);
			panelArray[j] = panel;
			setComponentZOrder(panel, 0);

			panel.addMouseMotionListener(new MouseMotionAdapter() {

				@Override
				public void mouseDragged(MouseEvent e) {
					// bal gomb nyomvatartásával az egér helyére kerül a hajó
					if (SwingUtilities.isLeftMouseButton(e)) {
						JPanel component = (JPanel) e.getComponent().getParent().getParent();
						Point pt = new Point(SwingUtilities.convertPoint(e.getComponent(), e.getPoint(), component));
						panel.setLocation((int) pt.getX() - (TILE_SIZE / 2), (int) pt.getY() - (TILE_SIZE / 2));
						currentlyPlacingShip = true;
					}
				}

			});

			panel.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseReleased(MouseEvent e) {
					// Megadja az egér koordinátáit az ablakon belül
					JPanel component = (JPanel) e.getComponent().getParent().getParent();
					Point pt = new Point(SwingUtilities.convertPoint(e.getComponent(), e.getPoint(), component));
					int counter1 = 0;
					int counter2 = 0;

					// kiszámolja a griden belüli pozíciót az egér koordinátái alapján
					int value = (int) pt.getX();

					while (ZERO_X + ((TILE_SIZE + BORDER_SIZE) * counter1) < value) {
						counter1++;
					}
					counter1--;

					int value2 = (int) (pt.getY());
					while (ZERO_Y + ((TILE_SIZE + BORDER_SIZE) * counter2) < value2) {
						counter2++;
					}
					counter2--;

					// Ha elengedésre kerül a bal gomb
					if (e.getButton() == MouseEvent.BUTTON1) {
						currentlyPlacingShip = false;
						leftClick(shipNum, counter1, counter2);
						// jobb gomb
					} else if (e.getButton() == MouseEvent.BUTTON3) {
						rightClick(shipNum, counter1, counter2);
					}

					finish.repaint();

				}

			});
		}
	}

	/*
	 * Jobb klikk esetén hívódik. A hajók forgatását teszi lehetővé
	 */
	private void rightClick(int shipNum, int x, int y) {
		// a függőlegesség a panel elrendezéséből adódik
		boolean isVertical = false;
		if (((BoxLayout) panelArray[shipNum].getLayout()).getAxis() == BoxLayout.Y_AXIS) {
			isVertical = true;
		}
		// hajó eltávolítása
		removeShip(shipArray[shipNum], isVertical);
		// a panel forgatása
		if (rotateShip(panelArray[shipNum]) && !currentlyPlacingShip) {
			// Ha sikerült, meghívódik a függvény, ami hozzáadja a hajót az új pozícióba
			addShip(shipArray[shipNum], new Point(x, y), !isVertical);
		} else if (!currentlyPlacingShip) {
			panelArray[shipNum].setLocation(shipArray[shipNum].getStartingPosition());
			rotateShip(panelArray[shipNum]);
		}

		showFinishButton();
	}

	/*
	 * Bal kattintásra hívódik meg (ha az egér egy hajó panelre mutat)
	 */
	private void leftClick(int shipNum, int x, int y) {
		// a panel egy X_AXIS elrendezésben van
		if ((((BoxLayout) panelArray[shipNum].getLayout()).getAxis() == BoxLayout.X_AXIS)) {
			// Megnézi, hogy a panel a griden van e
			if (x < gridArray.length - panelArray[shipNum].getWidth() / TILE_SIZE + 1 && x >= 0) {
				if (y < gridArray[0].length - panelArray[shipNum].getHeight() / TILE_SIZE + 1 && y >= 0) {
					// A jó helyre kerül elhelyezésre a hajó:
					placeShip(x, y, shipNum, false);
				} else {
					// Ha nem a griden van, visszakerül a kiinduló pozíciójába
					panelArray[shipNum].setLocation(shipArray[shipNum].getStartingPosition());
					// és kitörlődik a tömbből
					removeShip(shipArray[shipNum], false);
				}
			} else {
				// Ha nem a griden van, visszakerül a kiinduló pozíciójába
				panelArray[shipNum].setLocation(shipArray[shipNum].getStartingPosition());
				// és kitörlődik a tömbből
				removeShip(shipArray[shipNum], false);
			}
		// Egyébkén elforgatva rakja be
		} else {
			// Megnézi, hogy a panel a griden van e
			if (x < gridArray.length - panelArray[shipNum].getWidth() / TILE_SIZE + 1 && x >= 0) {
				if (y < gridArray[0].length - panelArray[shipNum].getHeight() / TILE_SIZE + 1 && y >= 0) {
					// A jó helyre kerül elhelyezésre a hajó:
					placeShip(x, y, shipNum, true);
				} else {
					// elforgatja
					rotateShip(panelArray[shipNum]);
					// Ha nem a griden van, visszakerül a kiinduló pozíciójába
					panelArray[shipNum].setLocation(shipArray[shipNum].getStartingPosition());
					// és kitörlődik a tömbből
					removeShip(shipArray[shipNum], true);
				}
			} else {
				// elforgatja
				rotateShip(panelArray[shipNum]);
				// Ha nem a griden van, visszakerül a kiinduló pozíciójába
				panelArray[shipNum].setLocation(shipArray[shipNum].getStartingPosition());
				// és kitörlődik a tömbből
				removeShip(shipArray[shipNum], true);
			}
		}

		showFinishButton();
	}

	/*
	 *  A hajó panel elhelyezése a a grid képen
	 */
	private void placeShip(int x, int y, int shipNum, boolean isVertical) {
		// bellítja a pozíciót
		panelArray[shipNum].setLocation(ZERO_X + x + (((TILE_SIZE + BORDER_SIZE) * x) + BORDER_SIZE / 2),
				ZERO_Y + y + ((TILE_SIZE + BORDER_SIZE) * y) + BORDER_SIZE / 2);
		// Megnézi, hogy van-e ütközés más panellel
		if (isIntersection(panelArray[shipNum])) {
			// Ha függőleges
			if (isVertical) {
				// akkor elforgatja a panelt
				rotateShip(panelArray[shipNum]);
			}
			// és kitörlődik a tömbből
			removeShip(shipArray[shipNum], false);
			// és visszaállítja a kiinduló pozíciójába a panelt
			panelArray[shipNum].setLocation(shipArray[shipNum].getStartingPosition());

			// Ha nincs ütközés:
		} else {
			removeShip(shipArray[shipNum], isVertical);
			addShip(shipArray[shipNum], new Point(x, y), isVertical);

		}
	}

	/*
	 *  A befejezés ("FINISH") gomb megjelenítését ellenőrző függvény
	 */
	private void showFinishButton() {
		boolean showButton = true;
		if (!currentlyPlacingShip) {
			for (int i = 0; i < shipArray.length; i++) {
				if (shipArray[i].getStartingPosition().equals(panelArray[i].getLocation())) {
					showButton = false;
				}
			}
			finish.setVisible(showButton);
		}
	}

	/*
	 * Két panel ütközését ellenőrző függvény
	 */
	private boolean isIntersection(JPanel p) {
		// Minden panlet megnéz
		for (int i = 0; i < panelArray.length; i++) {
			// Megnézi, h p ütközik-e magán kívűl mással
			if (p.getBounds().intersects(panelArray[i].getBounds()) && !p.equals(panelArray[i])) {
				return true;
			}
		}
		return false;
	}

	/*
	 * Eltávolítja a hajót a grid tömbből
	 */
	private void removeShip(Ship ship, boolean isVertical) {
		// végignézi a tömböt
		for (int i = 0; i < gridArray.length; i++) {
			for (int j = 0; j < gridArray[i].length; j++) {
				for (int k = 0; k < ship.getShipParts().length; k++) {
					if (gridArray[j][i] == (ShipPart) ship.getShipParts()[k]) {
						gridArray[j][i] = 1;
					}
				}
			}
		}
	}

	/*
	 * Hozzáad egy hajót a grid tömbhöz
	 */
	private void addShip(Ship ship, Point location, boolean isVertical) {

		// Ha a pozíció értelmes a tömbben
		if (location.getX() < gridArray.length && location.getX() >= 0 && location.getY() < gridArray.length
				&& location.getY() >= 0) {
			// AZ összes hajó részt megnézi
			for (int i = 0; i < ship.getShipParts().length; i++) {
				// Ha a hajó függőlegesen van forgatva
				if (isVertical) {
					// hajódarab hozzáadása a ponthoz, de i-vel eltova az y
					gridArray[(int) location.getX()][(int) location.getY() + i] = ship.getShipParts()[i];
				// egyébként
				} else {
					// hajódarab hozzáadása a ponthoz, de i-vel eltova az x
					gridArray[(int) location.getX() + i][(int) location.getY()] = ship.getShipParts()[i];
				}
			}
		}
	}

	/*
	 * A hajó panel elforgatása
	 */
	private boolean rotateShip(JPanel panel) {
		// Ha a panel x irányban áll
		if (((BoxLayout) panel.getLayout()).getAxis() == BoxLayout.X_AXIS) {
			if (panel.getX() > ZERO_X + ((TILE_SIZE + BORDER_SIZE) * gridArray.length) && !currentlyPlacingShip) {
				return false;
			}
			// átállítani y irányba
			panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			// felcserélni a magasságot és a szélességet
			int temp = panel.getWidth();
			int temp2 = panel.getHeight();
			panel.setSize(temp2, temp);

			for (int i = 0; i < panel.getComponentCount(); i++) {
				if (!panel.getComponent(i).getClass().toString().equals("JPanel")) {
					panel.add(Box.createRigidArea(new Dimension(0, BORDER_SIZE + 2)), i);
					panel.remove(++i);
				}
			}
			panel.add(Box.createRigidArea(new Dimension(0, 0)), 0);
			panel.remove(1);

			panel.validate();

			// panel új pozíciója
			panel.setLocation(panel.getX(), panel.getY());

			// a hajó hossza
			int counter = 0;
			while (ZERO_Y + ((TILE_SIZE + BORDER_SIZE) * counter) < panel.getY() + panel.getWidth()) {
				counter++;
			}
			counter--;

			// ha a hajó ütközik egy másikkal, vagy részlegesen lelóg a gridről
			if (!(counter <= gridArray[0].length - panel.getHeight() / TILE_SIZE && counter >= 0)
					|| isIntersection(panel)) {
				// akkor a forgatás sikertelen
				return false;
			}
			// ha a panel x irányban áll
		} else if (((BoxLayout) panel.getLayout()).getAxis() == BoxLayout.Y_AXIS) {
			// set the layout to y axis
			panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
			// felcserélni a magsságot és a szélességet
			int temp = panel.getWidth();
			int temp2 = panel.getHeight();
			panel.setSize(temp2, temp);

			for (int i = 0; i < panel.getComponentCount(); i++) {
				if (!panel.getComponent(i).getClass().toString().equals("JPanel")) {
					panel.add(Box.createRigidArea(new Dimension(BORDER_SIZE + 2, 0)), i);
					panel.remove(++i);
				}
			}
			panel.add(Box.createRigidArea(new Dimension(0, 0)), 0);
			panel.remove(1);

			panel.validate();

			// panel új pozíciója
			panel.setLocation(panel.getX(), panel.getY());

			// a hajó hossza
			int counter = 0;
			while (ZERO_X + ((TILE_SIZE + BORDER_SIZE) * counter) < panel.getX() + panel.getHeight()) {
				counter++;
			}
			counter--;

			// ha a hajó ütközik egy másikkal, vagy részlegesen lelóg a gridről
			if (!(counter <= gridArray.length - panel.getWidth() / TILE_SIZE && counter >= 0)
					|| isIntersection(panel)) {

				// akkor a forgatás sikertelen
				return false;
			}

		}
		// sikeres forgatás
		return true;
	}

	/*
	 * a grid array gettere
	 */
	public Object[][] getGridArray() {
		return gridArray;
	}

	/*
	 * vége a hajók elhelyezésének
	 */
	public boolean isFinished() {
		return setupOver;
	}

	public JButton getButton() {
		return finish;
	}

}
