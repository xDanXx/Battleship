import java.awt.*;
import java.io.IOException;
import javax.swing.*;

public class Main {

	public static int battleshipSize = 4;
	public static int cruiserSize = 3;
	public static int destroyerSize = 2;
	public static int submarineSize = 1;
	public static int battleshipCount = 1;
	public static int cruiserCount = 1;
	public static int destroyerCount = 1;
	public static int submarineCount = 1;

	private JFrame screen;
	private Comms mySocket;
	private boolean gameRunning;
	private boolean isServer;	// A játékos szerver vagy kliens

	private boolean startingIsServer;	// Az isServer-re inicializálódik

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		new Main().initScreen();
	}

	// Ablak inicializálása
	public void initScreen() throws IOException, ClassNotFoundException {
		screen = new JFrame();

		screen.getContentPane().setLayout(null);
		screen.getContentPane().setBackground(Color.WHITE);
		screen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		screen.setPreferredSize(new Dimension(900, 615));
		screen.setMinimumSize(new Dimension(900, 615));
		screen.setResizable(false);
		screen.pack();
		startGame();
	}

	// Főmenü meghívása (MainMenu)
	public void startGame() throws IOException, ClassNotFoundException {
		gameRunning = true;
		
		MainMenu startMenu = new MainMenu(screen);
		startMenu.loadFrontPage();
		while(startMenu.isScreenVisible()){}

		// Saját hajók kiválasztása
		Ship[] p1Ships = initializeShipCreation(true);
		MyGrid myGrid = new MyGrid(chooseShipPositions(p1Ships));

		// TCP kommunikáció
		// Hajók és grid átküldése
		// server küld először, utána kliens
		isServer = startMenu.isServer();
		startingIsServer = isServer;
		if (isServer){

			// socket inicializálás
			mySocket = new Comms(screen, startMenu.getPortNumber(),startMenu.getIPAddress(), true);

			// küldés (kiválasztott hajók és abból generált gridArray 2D tömb)
			mySocket.sendShipArray(p1Ships);
			mySocket.sendGridArray(myGrid.getGridArray());

			// fogadás (ellenséges hajók és 2D tömb)
			Ship[] p2Ships = mySocket.recieveShipArray();
			Grid enemyGrid = new Grid(mySocket.recieveGridArray());

			// Gridek elhelyezése a képernyőn
			myGrid.setLocation(enemyGrid.getWidth()+10, enemyGrid.getY());
			int windowWidth = myGrid.getX() + myGrid.getWidth() + 10;
			screen.setPreferredSize(new Dimension(windowWidth, screen.getHeight()));
			screen.setSize(screen.getPreferredSize());
			screen.pack();

			screen.getContentPane().add(enemyGrid);
			screen.getContentPane().add(myGrid);
			screen.addMouseListener(enemyGrid);
			screen.setVisible(true);

			// főprogram
			enemyGrid.setIsMyTurn(true);
			gameLoop(enemyGrid, myGrid);
		}
		else{

			// socket inicializálása
			mySocket = new Comms(screen, startMenu.getPortNumber(), startMenu.getIPAddress(), false);

			// fogadás (ellenséges hajók és 2D tömb)
			Ship[] p2Ships = mySocket.recieveShipArray();
			Grid enemyGrid = new Grid(mySocket.recieveGridArray());

			// küldés (kiválasztott hajók és abból generált gridArray 2D tömb)
			mySocket.sendShipArray(p1Ships);
			mySocket.sendGridArray(myGrid.getGridArray());

			// Gridek elhelyezése a képernyőn
			myGrid.setLocation(enemyGrid.getWidth()+10, enemyGrid.getY());
			int windowWidth = myGrid.getX() + myGrid.getWidth() + 10;
			screen.setPreferredSize(new Dimension(windowWidth, screen.getHeight()));
			screen.setSize(screen.getPreferredSize());
			screen.pack();

			screen.getContentPane().add(enemyGrid);
			screen.getContentPane().add(myGrid);
			screen.addMouseListener(enemyGrid);
			screen.setVisible(true);

			// főprogram
			enemyGrid.setIsMyTurn(false);
			gameLoop(enemyGrid, myGrid);
		}
	}

	// A hajók összefűzése egy tömbbe
	private Ship[] initializeShipCreation(boolean isPlayerOne) {
		Ship[] battleships = createShips(battleshipSize, battleshipCount, isPlayerOne);
		Ship[] cruisers = createShips(cruiserSize, cruiserCount, isPlayerOne);
		Ship[] destroyers = createShips(destroyerSize, destroyerCount, isPlayerOne);
		Ship[] submarines = createShips(submarineSize, submarineCount, isPlayerOne);

		Ship[] ships = concatShipArray(battleships, cruisers);
		ships = concatShipArray(ships, destroyers);
		ships = concatShipArray(ships, submarines);

		return ships;
	}

	// Hajók létrehozása a ShipPartokból
	private Ship[] createShips(int shipSize, int numOfShips, boolean isPlayerOne) {
		Ship[] listOfShips = new Ship[numOfShips];
		for (int i = 0; i < numOfShips; i++) {
			ShipPart[] shipArray = new ShipPart[shipSize];
			for (int j = 0; j < shipSize; j++) {
				ShipPart p = new ShipPart(isPlayerOne);
				shipArray[j] = p;
			}
			listOfShips[i] = new Ship(shipArray);
		}
		return listOfShips;
	}

	private Ship[] concatShipArray(Ship[] a, Ship[] b) {
		int aLen = a.length;
		int bLen = b.length;
		Ship[] c = new Ship[aLen + bLen];
		System.arraycopy(a, 0, c, 0, aLen);
		System.arraycopy(b, 0, c, aLen, bLen);
		return c;
	}

	// Hajók elhelyezése: GridCreator #Drag&Drop
	private Object[][] chooseShipPositions(Ship[] ships){
		GridCreator creator = new GridCreator(ships, screen);
		creator.initGrid();
		screen.getContentPane().add(creator);
		screen.getContentPane().repaint();
		screen.setVisible(true);
		while (!creator.isFinished()) {}
		screen.getContentPane().removeAll();
		screen.getContentPane().revalidate();
		screen.getContentPane().repaint();
		
		return creator.getGridArray();
	}

	// A játék közben ez a függvény fut
	// Váltakozva következnek a játékosok
	private void gameLoop(Grid grid, MyGrid small) throws IOException, ClassNotFoundException{
		// a YourTurn kép definialasa
		ImageIcon yourTurnImageIcon = new ImageIcon("YourTurn.png");
		JLabel yourTurnImageBin = new JLabel(yourTurnImageIcon);
		yourTurnImageBin.setSize(250, 250);
		yourTurnImageBin.setLocation(screen.getContentPane().getWidth() - yourTurnImageBin.getWidth()-50,
				screen.getHeight()-yourTurnImageBin.getHeight()-100);
		screen.getContentPane().add(yourTurnImageBin);
		yourTurnImageBin.setVisible(false);

		// az EnemyTurn kép definialasa
		ImageIcon enemyTurnImageIcon = new ImageIcon("EnemyTurn.png");
		JLabel enemyTurnImageBin = new JLabel(enemyTurnImageIcon);
		enemyTurnImageBin.setSize(250, 250);
		enemyTurnImageBin.setLocation(screen.getContentPane().getWidth() - enemyTurnImageBin.getWidth()-50,
				screen.getHeight()-enemyTurnImageBin.getHeight()-100);
		screen.getContentPane().add(enemyTurnImageBin);
		enemyTurnImageBin.setVisible(false);

		// **************************** FŐCIKLUS **********************************
		while (gameRunning) {

			// Annak függvényében, hogy az ellenség vagy saját kör éppen
			// Váltakozik, hogy mi kerül megjelenítésre a jobb alsó sarokban
			yourTurnImageBin.setVisible(grid.getIsMyTurn());
			enemyTurnImageBin.setVisible(!grid.getIsMyTurn());
			screen.repaint();

			// Várakozás 0.5mp
			try {
				Thread.sleep(500);
			} catch (Exception e) {}

			grid.repaint();
			small.repaint();

			// ideiglenes változók
			Object[][] tempEnemyGrid = grid.getGridArray();
			Object[][] tempMyGrid = small.getGridArray();
			boolean p2AllShipsDead = true;
			boolean p1AllShipsDead = true;


			// Megnézi, hogy maradt-e ép hajója az ellenfélnek
			for(int i = 0; i < tempEnemyGrid.length; i++) {
				for (int j = 0; j < tempEnemyGrid[i].length; j++) {
					if (tempEnemyGrid[i][j].getClass().getName().equals("ShipPart")) {
						if (!((ShipPart) tempEnemyGrid[i][j]).isDestroy()) {
							p2AllShipsDead = false;
						}
					}
				}
			}

			// Megnézi, hogy marad-e ép hajója a játékosnak
			for(int i = 0; i < tempMyGrid.length; i++) {
				for (int j = 0; j < tempMyGrid[i].length; j++) {
					if (tempMyGrid[i][j].getClass().getName().equals("ShipPart")) {
						if (!((ShipPart) tempMyGrid[i][j]).isDestroy()) {
							p1AllShipsDead = false;
						}
					}
				}
			}
			// Ha valakinek nincs ép hajója
			if (p1AllShipsDead || p2AllShipsDead) {
				gameRunning = false;
				for (int i = 0; i < grid.getGridArray().length; i++) {
					for (int j = 0; j < grid.getGridArray()[i].length; j++) {
						if ((grid.getGridArray()[i][j].equals(1))) {
							grid.getGridArray()[i][j] = 0;
						}
					}
				}
				yourTurnImageBin.setVisible(false);
				enemyTurnImageBin.setVisible(false);
				gameOver(p1AllShipsDead);
			}

			if (isServer) {
				// kuldes
				mySocket.sendGridArray(grid.getGridArray());
				mySocket.sendMyTurn(!grid.getIsMyTurn());
				// fogadas
				small.setGridArray(mySocket.recieveGridArray());
				grid.setIsMyTurn(mySocket.recieveMyTurn());
			}else {
				// fogadas
				small.setGridArray(mySocket.recieveGridArray());
				grid.setIsMyTurn(mySocket.recieveMyTurn());
				// kuldes
				mySocket.sendGridArray(grid.getGridArray());
				mySocket.sendMyTurn(!grid.getIsMyTurn());
			}

			// A küldés és fogadás sorrendjét felcseréli
			if(grid.getIsMyTurn()){
				isServer = true;
			}
			else{
				isServer = false;
			}
		}
	}

	// Ha valakinek elfogytak a hajói: játék vége
	private void gameOver(boolean p1AllShipsDead) throws IOException{
		ImageIcon gameOverLogo;
		if (p1AllShipsDead){
			if(startingIsServer) {
				gameOverLogo = new ImageIcon("ClientPlayerWon.png");
			}
			else {
				gameOverLogo = new ImageIcon("ServerPlayerWon.png");
			}

		}else{
			if(startingIsServer) {
				gameOverLogo = new ImageIcon("ServerPlayerWon.png");
							}
			else {
				gameOverLogo = new ImageIcon("ClientPlayerWon.png");
			}


		}
		JLabel gameOverLogoBin = new JLabel(gameOverLogo);
		gameOverLogoBin.setSize(250, 250);
		gameOverLogoBin.setLocation(screen.getContentPane().getWidth() - gameOverLogoBin.getWidth() - 50,
				screen.getHeight()-gameOverLogoBin.getHeight()-100);
		gameOverLogoBin.setVisible(true);
		screen.getContentPane().add(gameOverLogoBin);

		JButton closeBtn = new JButton("Close!");
		closeBtn.setSize(150, 50);
		closeBtn.setLocation(screen.getContentPane().getWidth() - closeBtn.getWidth() - 100,
				screen.getHeight()-closeBtn.getHeight()-50);
		closeBtn.addActionListener(e -> {
			System.exit(0);
		});
		closeBtn.setVisible(true);
		screen.getContentPane().add(closeBtn);

		screen.getContentPane().revalidate();
		screen.getContentPane().repaint();
	}
}