import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;

public class MainMenu {
	
	private JFrame screen;
	private ImageIcon logoImageIcon;
	private JLabel logoImageBin;
	private JButton startGame;
	private JButton serverBtn;
	private JButton clientBtn;
	private JLabel selectMessage;
	private JLabel myIP;
	private JLabel IPMessage;
	private JLabel portMessage;
	private JLabel portErrorMessage;
	private JTextField portTextField;
	private JTextField IPTextField;

	private String portNumberString;
	private int portNumberInt;
	private String IPAddress;
	private volatile boolean isScreenVisible;
	private volatile boolean isServer;

	// konstruktor
	public MainMenu(JFrame theWindow){
		screen = theWindow;
		logoImageIcon = new ImageIcon("Logo.png");
		logoImageBin = new JLabel(logoImageIcon);
		isScreenVisible = true;
	}
	
	public void loadFrontPage() {
		// logo megjelenitese
		logoImageBin.setSize(screen.getContentPane().getWidth(), screen.getContentPane().getHeight()/2);
		logoImageBin.setLocation(0, 0); 
		logoImageBin.setVisible(true);

		// szoveg kiirasa a network mode valasztasahoz
		selectMessage = new JLabel("Select your network mode!");
		selectMessage.setForeground(Color.GRAY);
		selectMessage.setFont(new Font("Impact", Font.PLAIN, 16));
		selectMessage.setSize(250, 50);
		selectMessage.setLocation(screen.getContentPane().getWidth() - selectMessage.getWidth() - 250,
				logoImageBin.getHeight() + 40);
		selectMessage.setVisible(true);

		// szoveg kiirasa a port szam beirasahoz
		portMessage = new JLabel("Port number:");
		portMessage.setForeground(Color.GRAY);
		portMessage.setFont(new Font("Impact", Font.PLAIN, 16));
		portMessage.setSize(150, 50);
		portMessage.setLocation(screen.getContentPane().getWidth() - portMessage.getWidth() - 250,
				screen.getHeight()-portMessage.getHeight() - 130);
		portMessage.setVisible(true);

		// szoveg kiirasa az IP cim beirasahoz
		IPMessage = new JLabel("IP address:");
		IPMessage.setForeground(Color.GRAY);
		IPMessage.setFont(new Font("Impact", Font.PLAIN, 16));
		IPMessage.setSize(150, 50);
		IPMessage.setLocation(screen.getContentPane().getWidth() - IPMessage.getWidth() - 250,
				screen.getHeight()-IPMessage.getHeight() - 90);
		IPMessage.setVisible(false);

		// szoveg kiirasa a rosszul megadott port szam jelzesehez
		portErrorMessage = new JLabel("Incorrect port number format!");
		portErrorMessage.setForeground(Color.RED);
		portErrorMessage.setFont(new Font("Impact", Font.PLAIN, 20));
		portErrorMessage.setSize(300, 50);
		portErrorMessage.setLocation(150, screen.getHeight()-portErrorMessage.getHeight() - 50);
		portErrorMessage.setVisible(false);

		// szoveg kiirasa az IP cimrol
		try {
			String myIPaddress = InetAddress.getLocalHost().getHostAddress();
			myIP = new JLabel("Your IP address: " + myIPaddress);
			myIP.setForeground(Color.WHITE);
			myIP.setFont(new Font("Impact", Font.PLAIN, 16));
			myIP.setSize(200, 50);
			myIP.setLocation(screen.getContentPane().getWidth() - myIP.getWidth() - 20,
					screen.getHeight()-myIP.getHeight() - 40);
			myIP.setVisible(true);
			screen.getContentPane().add(myIP);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		// start gomb megjelenitese
		startGame = new JButton("Start Game");
		startGame.setSize(200, 100);
		startGame.setLocation(150, logoImageBin.getHeight() + 50);
		startGame.setEnabled(false);
		startGame.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				portNumberString = portTextField.getText();
				IPAddress = IPTextField.getText();
				try{
					portNumberInt = Integer.parseInt(portNumberString);
					if(portNumberInt > 0 && portNumberInt < 65536) {
						screen.getContentPane().remove(startGame);
						screen.getContentPane().remove(serverBtn);
						screen.getContentPane().remove(clientBtn);
						screen.getContentPane().remove(logoImageBin);
						screen.getContentPane().remove(selectMessage);
						screen.getContentPane().remove(portMessage);
						screen.getContentPane().remove(portTextField);
						screen.getContentPane().remove(portErrorMessage);
						screen.getContentPane().remove(IPMessage);
						screen.getContentPane().remove(IPTextField);
						screen.getContentPane().remove(myIP);
						screen.getContentPane().setBackground(Color.WHITE);
						screen.getContentPane().revalidate();
						screen.getContentPane().repaint();
						isScreenVisible = false;
					} else{
						portErrorMessage.setVisible(true);
					}
				} catch (NumberFormatException e) {
					portErrorMessage.setVisible(true);
				}
			}
		});

		// server gomb megjelenitese
		serverBtn = new JButton("Server");
		serverBtn.setSize(200, 50);
		serverBtn.setLocation(screen.getContentPane().getWidth() - serverBtn.getWidth() - 300,
				logoImageBin.getHeight() + selectMessage.getHeight() + 50);
		serverBtn.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				startGame.setEnabled(true);
				serverBtn.setBackground(Color.LIGHT_GRAY);
				clientBtn.setBackground(Color.WHITE);
				IPMessage.setVisible(false);
				IPTextField.setVisible(false);
				isServer = true;
			}
		});

		// client gomb megjelenitese
		clientBtn = new JButton("Client");
		clientBtn.setSize(200, 50);
		clientBtn.setLocation(screen.getContentPane().getWidth() - clientBtn.getWidth() - 100,
				logoImageBin.getHeight() + selectMessage.getHeight() + 50);
		clientBtn.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				startGame.setEnabled(true);
				clientBtn.setBackground(Color.LIGHT_GRAY);
				serverBtn.setBackground(Color.WHITE);
				IPMessage.setVisible(true);
				IPTextField.setVisible(true);
				isServer = false;
			}
		});

		// port szam beirasahoz szovegdoboz
		portTextField = new JTextField();
		portTextField.setSize(150, 30);
		portTextField.setLocation(screen.getContentPane().getWidth() - portTextField.getWidth() - 150,
				screen.getHeight()-portTextField.getHeight() - 140);
		portTextField.setVisible(true);

		// IP cim beirasahoz szovegdoboz
		IPTextField = new JTextField();
		IPTextField.setSize(150, 30);
		IPTextField.setLocation(screen.getContentPane().getWidth() - IPTextField.getWidth() - 150,
				screen.getHeight()-IPTextField.getHeight() - 100);
		IPTextField.setVisible(false);

		//egyeb dolgok beallitasa
		startGame.setVisible(true);
		serverBtn.setVisible(true);
		clientBtn.setVisible(true);
		screen.getContentPane().add(startGame);
		screen.getContentPane().add(serverBtn);
		screen.getContentPane().add(clientBtn);
		screen.getContentPane().add(logoImageBin);
		screen.getContentPane().add(selectMessage);
		screen.getContentPane().add(portMessage);
		screen.getContentPane().add(IPMessage);
		screen.getContentPane().add(portErrorMessage);
		screen.getContentPane().add(portTextField);
		screen.getContentPane().add(IPTextField);
		screen.getContentPane().setBackground(Color.BLACK);
		screen.setVisible(true);
		screen.getContentPane().revalidate();
		screen.getContentPane().repaint();
	}

	// visszaadja hogy a logo lathato-e
	public boolean isScreenVisible(){
		return isScreenVisible;
	}

	// visszaadja a port szamot
	public int getPortNumber() {
		return portNumberInt;
	}

	public String getIPAddress() {
		return IPAddress;
	}

	public boolean isServer() {
		return isServer;
	}

}
