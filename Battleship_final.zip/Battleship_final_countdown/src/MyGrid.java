import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class MyGrid extends JPanel {
	private static final long serialVersionUID = 1L;
	private Object[][] gridArray;
	private BufferedImage gridImage;
	public static final int ZERO_X = 23; // X koordinátája a bal felső saroknak
	public static final int ZERO_Y = 39; // y koordinátája a bal felső saroknak
	public static final int TILE_SIZE = 20; // csempe mérete
	public static final int BORDER_SIZE = 3; // csempék közti terület mérete
	public static final int PIECE_SIZE = 18; 

	/*
	 * Konstruktor ami egy 2D tömböt kap: mezők tömbje
	 */
	public MyGrid(Object[][] array) {
		this.gridArray = array;
		
		// háttér fehér
		setBackground(Color.WHITE);
		setPreferredSize(new Dimension((ZERO_X + 2 + (TILE_SIZE+BORDER_SIZE)*array.length),
				ZERO_Y+ 2 + ((TILE_SIZE+BORDER_SIZE)*array.length)));
		setSize(getPreferredSize());
		
		// betölti a grid fájlt
		try {
			gridImage = ImageIO.read(new File("gridSmallLabels.png"));
		} catch (IOException e) {
			System.out.println("Failed to load image");
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		// megrajzoja a gridet
		g2.drawImage(gridImage, 0, 15, this);

		// végignézi a tömböt
		for (int i = 0; i < gridArray.length; i++) {
			for (int j = 0; j < gridArray[i].length; j++) {
				// Ha van hajó darab a mezőn
				if ((gridArray[i][j]).getClass().getName().equals("ShipPart")) {
					// Akkor a hozzátartozó képet megjeleníti
					g2.drawImage(((ShipPart) gridArray[i][j]).getShipImage(),
							ZERO_X + 2 + ((TILE_SIZE + BORDER_SIZE) * i) + BORDER_SIZE/2,
							ZERO_Y + 2 + ((TILE_SIZE + BORDER_SIZE) * j) + BORDER_SIZE/2,
							PIECE_SIZE, PIECE_SIZE, this);
				}
			}
		}
	}

	/*
	 * Visszaadja a tömböt
	 */
	public Object[][] getGridArray() {
		return gridArray;
	}

	/*
	 * Átállítja a tömböt
	 */
	public void setGridArray(Object[][] array) {
		this.gridArray = array;
	}

}
