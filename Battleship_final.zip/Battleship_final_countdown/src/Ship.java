import java.awt.*;
import java.io.Serializable;

public class Ship implements Serializable {
	private ShipPart[] parts;
	private Point startingPosition;

	//konstruktor
	Ship(ShipPart[] list) {
		parts = list;
		startingPosition = new Point(0,0);
	}
	

	//visszadaja a shiPart-okat
	public ShipPart[] getShipParts() {
		return parts;
	}

	// kezdopont beallitasa
	public void setStartingPosition(Point sp){
		startingPosition = sp;
	}

	// kezdopont lekerdezese
	public Point getStartingPosition(){
		return startingPosition;
	}
}