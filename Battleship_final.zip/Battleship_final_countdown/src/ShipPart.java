import java.awt.*;
import java.io.Serializable;
import javax.swing.*;

public class ShipPart implements Serializable {
	private ImageIcon shipPartAlive;
	private boolean shipPartHit;
	boolean isPlayerServer;

	// konstruktor
	public ShipPart(boolean isPlayerServer) {
		this.isPlayerServer = isPlayerServer;
		// a jatekoshoz tartozo kep beallitasa
		if (isPlayerServer)
			shipPartAlive = new ImageIcon("PlayerServer.png");
		else
			shipPartAlive = new ImageIcon("PlayerClient.png");
		shipPartHit = false;
	}

	// a jatekoshoz tartozo kep beallitasa
	public void setShipImage(String file) {
		shipPartAlive = new ImageIcon(file);
	}

	// a jatekoshoz tartozo kep lekerdezese
	public Image getShipImage() {
		return shipPartAlive.getImage();
	}

	// a shipPart elpusztitasa, a jatekoshoz tartozo allapot es kep atallitasaval
	public void destroy() {
		shipPartHit = true;
		if (isPlayerServer) {
			setShipImage("PlayerServerHit.png");
		} else {
			setShipImage("PlayerClientHit.png");
		}
	}

	// a shipPart allapotat adja vissza
	public boolean isDestroy() {
		return shipPartHit;
	}
}
